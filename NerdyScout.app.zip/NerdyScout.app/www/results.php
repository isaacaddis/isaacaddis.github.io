<html>
  <head>
    <h1>Your Answers</h1>
  </head>
  <body>
    <?php
       if(isset($_POST["submit"])) {
         $team = $_POST["team"]
       }

    // function test_input($data) {
    //   $data = trim($data);
    //   $data = stripslashes($data);
    //   $data = htmlspecialchars($data);
    //   return $data;
    // }
    ?>
  </body>
</html>
